package ru.job4j.generics;

public class Animal {
    @Override
    public String toString() {
        return "Animal";
    }
}
